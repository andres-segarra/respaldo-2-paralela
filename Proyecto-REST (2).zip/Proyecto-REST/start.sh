#!/bin/env bash

# Run with npm
# npm run dev


# Run with docker
docker compose build && docker compose up
